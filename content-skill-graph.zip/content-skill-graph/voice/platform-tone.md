# Platform Tone Adaptations

Core voice defined in [Brand Voice](brand-voice.md). This file defines
how that voice *adapts* per platform. See [Humanizer](humanizer.md) for
AI writing patterns to strip from every post regardless of platform.

## LinkedIn

- Most professional version of the voice, and by far the shortest. Target 250 to
  400 characters of copy (the booking line does not count toward it), two to
  four sentences plus that booking line. See
  [LinkedIn](../platforms/linkedin.md) and [Reference Posts](reference-posts.md).
- Buyer-first framing, write for talent buyers, bookers, and industry peers, but never use the word "buyer" or "talent buyer" in the post itself. Address them as "you", or use neutral phrases like "those unfamiliar with the act" or "anyone who hasn't seen them live." They know who they are.
- Lead with the result: a sold-out run, an award, a re-booking, a press win. State the specific proof, then make the ask. One fact, not a stack of them.
- Confident authority, not casual enthusiasm. Specifics over adjectives.
- Example: "Kelly O'Brien sold out her third run of THE DOLLY SHOW this season. Named the UK's best Dolly tribute four years running. Booking inquiries: info@loveproductions.com."
- The booking CTA is the agency email, on every social channel that carries one.
- **News, not flyers.** No upcoming shows, tour dates, or ticket links on LinkedIn. Those go to Instagram and Facebook. LinkedIn is for proof: results, awards, press, re-bookings.
- **LP acts only.** Never post about an original artist's own tours, milestones, or news on LinkedIn. If the topic is `original_artist_news`, `trivia`, `historical_fact`, or `upcoming_show`, skip LinkedIn entirely.
- **Conservative by default.** When in doubt, don't post on LinkedIn. A missed opportunity beats a post that looks like a flyer or like we're riding another artist's momentum.

## Instagram

- Fan-first, visual-first. The image/video stops the scroll, text supports it.
- Shorter captions. Bold, punchy, energetic.
- Aspirational and inviting, "you need to be there," "tickets going fast."
- Carousel captions: one bold idea per slide. Max 8 words on slide 1.
- Hashtags: **at most 5** at the end, a hard Buffer limit. Act and artist tags
  first, then location. See [Instagram](../platforms/instagram.md).
- **The CTA is always one of two fixed lines, never a URL and never an email.**
  Show announcements get "Link in bio for more info on tickets and booking."
  (client direction 2026-08-17); everything else gets "Link in bio to set up an
  appointment for booking." (client direction 2026-08-04). Captions do not
  linkify, so a URL is dead text, and an email is a higher bar than tapping the
  bio link. See [Instagram](../platforms/instagram.md).
- Example: "Sold out. Again. 🎸 The Dolly Show returns this fall.
  Link in bio to set up an appointment for booking."

## Facebook

- Warmest and most community-oriented version of the voice.
- Fan-and-family energy. Ask questions, invite discussion, celebrate together.
- More personal context. Share the story behind the show.
- Great for event posts, post-show recaps, and fan appreciation.
- Longer captions welcome, Facebook readers will actually read them.
- Example: "What a night. The Dolly Show had the crowd on their feet from
  the first song to the last. Were you there? Tell us your favorite moment
  in the comments, we read every one."

## The Rule

When adapting across platforms: CHANGE the framing first.
LinkedIn = convince the buyer. Instagram = excite the fan. Facebook = celebrate
with the community. The voice stays the same, only the angle changes.
