# Repurposing Chain

One idea enters. Three platform-native posts come out. Each one
thinks about the topic differently, this is *not* reformatting.

## The Chain Order

Write in this order. Each step builds on the previous but adapts.

### Step 1: [LinkedIn](../platforms/linkedin.md) (Write First: Buyer Angle)

LinkedIn forces you to lead with proof and business value. Starting here
ensures the core result and credibility are clear before you adapt for fans.

- Frame it for buyers: sold-out results, re-bookings, awards, press, milestones.
  Not upcoming shows or ticket dates, those are Instagram and Facebook only.
- Output: short professional post, 250-400 characters of copy, two to four
  sentences. Not a paragraph.
- End with the one-line booking CTA: "Booking inquiries: info@loveproductions.com".
- Note: for show/date topics and original-artist topics, LinkedIn is skipped
  entirely. Writing the buyer angle first is still a useful thinking step, but
  only genuine tribute-act news actually gets posted to LinkedIn.

### Step 2: [Instagram](../platforms/instagram.md) (Fan Energy, Visual First)

Strip the business framing. Lead with the visual excitement and fan experience.
The angle shifts from "why buyers should book this act" to "why fans can't miss
this show."

- LinkedIn says: "The Dolly Show sold out three consecutive runs this season,
  with patron satisfaction reviews averaging 4.9/5."
- Instagram says: "SOLD OUT. Again. 🎸 The Dolly Show is back this fall, 
  and tickets will go fast. Link in bio to set up an appointment for booking."
- Output: Image or carousel post + caption with hashtags and whichever of the two
  fixed CTAs fits (see [Instagram](../platforms/instagram.md); a show
  announcement gets the tickets one).

### Step 3: [Facebook](../platforms/facebook.md) (Community, Conversation)

Take the Instagram energy and warm it up. Add personal context and
an invitation to engage. Frame it as sharing good news with the community,
not broadcasting to an audience.

- Output: Post with a question or invitation at the end.
- Share to relevant local groups and events pages.

## The Litmus Test

Each platform version should pass this test:

"If someone followed us on *all* three platforms, would they be annoyed
seeing the same thing everywhere?"

If yes → you're reformatting, not rethinking. Go back.
If no → you've made 3 unique pieces from one idea. That's the goal.

## What Actually Changes Between Platforms

| Element | How It Adapts                                            |
| ------- | -------------------------------------------------------- |
| Angle   | Buyer proof → Fan excitement → Community warmth          |
| Hook    | Rewritten per platform                                   |
| Tone    | Professional → Energetic → Warm. See [Platform Tone][pt] |
| Format  | Short proof post → Visual caption → Discussion post      |
| CTA     | "Book now" → "Get tickets" → "Were you there?"           |

## Batch Workflow

1. Write ALL three platform versions in one session, not across days.
2. Follow the chain order. Each step feeds the next.
3. Review all three outputs together before publishing any.
4. Schedule using [Scheduling](scheduling.md) to stagger across the week.

[pt]: ../voice/platform-tone.md
